مشروع تطبيق إدارة التوصيلات للـ iPhone
=====================================

اسم التطبيق بالعبرية: ניהול משלוחים
Bundle ID الافتراضي: com.ata.deliverymanager

مهم جدًا
--------
هذا مشروع مصدر جاهز للبناء، وليس IPA موقّعًا. توقيع IPA ورفعه إلى TestFlight يتطلبان ربط حساب Apple Developer/App Store Connect الخاص بك بخدمة بناء سحابية مثل Codemagic. لا ترسل لي كلمة مرور Apple أو مفتاح API السري.

الطريقة الأسهل بدون جهاز Mac
----------------------------
1. أنشئ حسابًا في GitHub.
2. أنشئ مستودعًا جديدًا وارفع جميع محتويات هذا المجلد إليه، وليس ملف ZIP داخل المستودع فقط.
3. أنشئ حسابًا في Codemagic وسجّل الدخول بواسطة GitHub.
4. أضف المستودع كتطبيق جديد.
5. في App Store Connect أنشئ تطبيقًا جديدًا:
   - الاسم: ניהול משלוחים
   - Bundle ID: com.ata.deliverymanager
   - SKU: delivery-manager-he-001
6. من App Store Connect أنشئ API Key بصلاحية App Manager، ثم أضفه في:
   Codemagic > Team settings > Integrations > App Store Connect
   وسمِّ التكامل بالضبط: Ata_App_Store_Connect
7. في ملف codemagic.yaml استبدل:
   REPLACE_WITH_APPLE_APP_ID
   بالرقم الخاص بالتطبيق من App Store Connect، وليس Apple ID البريد الإلكتروني.
8. في Codemagic اختر Start new build ثم workflow باسم ios-testflight.
9. عند نجاح البناء سيرتفع التطبيق تلقائيًا إلى TestFlight.
10. افتح تطبيق TestFlight على iPhone وثبّت التطبيق.

إعداد التوقيع
-------------
داخل Codemagic فعّل Automatic code signing لحساب Apple. Bundle ID في Apple وCodemagic وcapacitor.config.json يجب أن يكون متطابقًا تمامًا.

الخصوصية والبيانات
------------------
الطلبات والصور تُحفظ محليًا داخل التطبيق على الجهاز. حذف التطبيق قد يحذف البيانات؛ استخدم النسخة الاحتياطية من داخل التطبيق دوريًا.

ميزة OCR
--------
الميزة الحالية تستخدم Tesseract داخل التطبيق وتحتاج إلى اتصال إنترنت عند تحميل ملفات اللغة للمرة الأولى. يجب مراجعة الاسم والهاتف والعنوان قبل حفظ الطلب.

ملاحظات
-------
- لا تغيّر اسم مجلد www.
- عند تعديل ملفات التطبيق شغّل بناء جديد في Codemagic.
- إذا كان Bundle ID مستخدمًا مسبقًا، غيّره في capacitor.config.json وcodemagic.yaml وفي App Store Connect إلى قيمة فريدة.
