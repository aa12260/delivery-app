const DB_NAME='delivery_manager_he', STORE='orders';
let db;
const typeInfo={regular:['משלוח רגיל',10],drinks:['משלוח שתיה',20],vegetables:['משלוח ירקות',10]};
const $=s=>document.querySelector(s);
function toast(t){const el=$('#toast');el.textContent=t;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),1800)}
function openDB(){return new Promise((res,rej)=>{const r=indexedDB.open(DB_NAME,1);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains(STORE))r.result.createObjectStore(STORE,{keyPath:'id',autoIncrement:true})};r.onsuccess=()=>{db=r.result;res()};r.onerror=()=>rej(r.error)})}
function tx(mode='readonly'){return db.transaction(STORE,mode).objectStore(STORE)}
function addOrder(o){return new Promise((res,rej)=>{const r=tx('readwrite').add(o);r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})}
function putOrder(o){return new Promise((res,rej)=>{const r=tx('readwrite').put(o);r.onsuccess=()=>res();r.onerror=()=>rej(r.error)})}
function deleteOrder(id){return new Promise((res,rej)=>{const r=tx('readwrite').delete(id);r.onsuccess=()=>res();r.onerror=()=>rej(r.error)})}
function allOrders(){return new Promise((res,rej)=>{const r=tx().getAll();r.onsuccess=()=>res(r.result.sort((a,b)=>b.loadedAt-a.loadedAt));r.onerror=()=>rej(r.error)})}
function fmt(ts){return ts?new Intl.DateTimeFormat('he-IL',{dateStyle:'short',timeStyle:'short'}).format(new Date(ts)):'—'}
function esc(v=''){return String(v).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
function fileData(file){return new Promise((res,rej)=>{if(!file)return res(null);const r=new FileReader();r.onload=()=>res(r.result);r.onerror=()=>rej(r.error);r.readAsDataURL(file)})}

document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>{document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));b.classList.add('active');document.querySelectorAll('.panel').forEach(p=>p.classList.add('hidden'));$('#'+b.dataset.tab).classList.remove('hidden');if(b.dataset.tab==='orders')renderOrders();if(b.dataset.tab==='stats')renderStats()});

$('#orderForm').onsubmit=async e=>{e.preventDefault();const p=await fileData($('#photo').files[0]);const type=$('#type').value;await addOrder({type,name:$('#name').value.trim(),phone:$('#phone').value.trim(),address:$('#address').value.trim(),notes:$('#notes').value.trim(),photo:p,loadedAt:Date.now(),deliveredAt:null,pay:typeInfo[type][1]});e.target.reset();toast('ההזמנה נשמרה');};

async function renderOrders(){const q=$('#search').value.trim().toLowerCase();let arr=await allOrders();if(q)arr=arr.filter(o=>[o.name,o.phone,o.address,o.notes,typeInfo[o.type][0]].join(' ').toLowerCase().includes(q));const box=$('#ordersList');if(!arr.length){box.innerHTML='<div class="empty">אין הזמנות להצגה</div>';return}box.innerHTML=arr.map(o=>`<div class="order ${o.deliveredAt?'done':''}"><div class="row"><div><span class="badge">${typeInfo[o.type][0]} · ${o.pay} ₪</span><h3 style="margin:8px 0 2px">${esc(o.name)}</h3><div class="meta">📞 ${esc(o.phone||'—')}<br>📍 ${esc(o.address)}<br>⏱ טעינה: ${fmt(o.loadedAt)}<br>✅ מסירה: ${fmt(o.deliveredAt)}${o.notes?'<br>📝 '+esc(o.notes):''}</div></div>${o.photo?`<img class="thumb" src="${o.photo}" alt="תמונה" />`:''}</div><div class="actions" style="margin-top:10px">${!o.deliveredAt?`<button class="btn success" onclick="markDone(${o.id})">סמן כנמסר</button>`:`<button class="btn ghost" onclick="undoDone(${o.id})">בטל מסירה</button>`}<button class="btn danger" onclick="removeOrder(${o.id})">מחק</button></div></div>`).join('')}
$('#search').oninput=renderOrders;
window.markDone=async id=>{const arr=await allOrders(),o=arr.find(x=>x.id===id);o.deliveredAt=Date.now();await putOrder(o);renderOrders();toast('זמן המסירה נשמר')};
window.undoDone=async id=>{const arr=await allOrders(),o=arr.find(x=>x.id===id);o.deliveredAt=null;await putOrder(o);renderOrders()};
window.removeOrder=async id=>{if(confirm('למחוק את ההזמנה?')){await deleteOrder(id);renderOrders();toast('ההזמנה נמחקה')}};

async function renderStats(){const a=await allOrders(),now=new Date();const day=a.filter(o=>{const d=new Date(o.loadedAt);return d.toDateString()===now.toDateString()});const mon=a.filter(o=>{const d=new Date(o.loadedAt);return d.getFullYear()===now.getFullYear()&&d.getMonth()===now.getMonth()});const set=(p,x)=>{$('#'+p+'Count').textContent=x.length;$('#'+p+'Done').textContent=x.filter(o=>o.deliveredAt).length;$('#'+p+'Pay').textContent=x.filter(o=>o.deliveredAt).reduce((s,o)=>s+o.pay,0)+' ₪'};set('today',day);set('month',mon)}
function dl(name,data,type){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([data],{type}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
$('#exportCsv').onclick=async()=>{const a=await allOrders();const rows=[['ID','סוג','שם','טלפון','כתובת','הערות','זמן טעינה','זמן מסירה','שכר'],...a.map(o=>[o.id,typeInfo[o.type][0],o.name,o.phone,o.address,o.notes,new Date(o.loadedAt).toISOString(),o.deliveredAt?new Date(o.deliveredAt).toISOString():'',o.pay])];const csv='\ufeff'+rows.map(r=>r.map(v=>'"'+String(v??'').replaceAll('"','""')+'"').join(',')).join('\n');dl('deliveries.csv',csv,'text/csv;charset=utf-8')};
$('#backup').onclick=async()=>dl('deliveries-backup.json',JSON.stringify(await allOrders()),'application/json');
$('#restoreBtn').onclick=()=>$('#restoreFile').click();
$('#restoreFile').onchange=async e=>{try{const arr=JSON.parse(await e.target.files[0].text());for(const o of arr){delete o.id;await addOrder(o)}toast('הגיבוי שוחזר')}catch{alert('קובץ גיבוי לא תקין')}};
$('#clearAll').onclick=async()=>{if(confirm('למחוק את כל ההזמנות?')){await new Promise((res,rej)=>{const r=tx('readwrite').clear();r.onsuccess=res;r.onerror=()=>rej(r.error)});renderStats();toast('כל הנתונים נמחקו')}};

(async()=>{await openDB();if('serviceWorker'in navigator)navigator.serviceWorker.register('sw.js').catch(()=>{});})();

function normalizeOcrText(text=''){
  return text.replace(/[|]/g,' ').replace(/\s+/g,' ').trim();
}
function extractPhone(text){
  const matches=text.match(/(?:\+?972[-\s]?)?0?5\d(?:[-\s]?\d){7}|0[2-9](?:[-\s]?\d){7}/g)||[];
  if(!matches.length)return '';
  let phone=matches[0].replace(/[^\d+]/g,'');
  if(phone.startsWith('972'))phone='+'+phone;
  return phone;
}
function cleanLine(line){return line.replace(/[•|:_=]+/g,' ').replace(/\s+/g,' ').trim()}
function valueAfterLabel(lines,labels){
  for(let i=0;i<lines.length;i++){
    const l=lines[i];
    for(const label of labels){
      const re=new RegExp(label+'\\s*[:\\-]?\\s*(.*)$','i');
      const m=l.match(re);
      if(m&&m[1]&&m[1].trim().length>1)return cleanLine(m[1]);
      if(re.test(l)&&lines[i+1])return cleanLine(lines[i+1]);
    }
  }
  return '';
}
function extractFields(raw){
  const lines=raw.split(/\n+/).map(cleanLine).filter(x=>x.length>1);
  const phone=extractPhone(raw);
  let name=valueAfterLabel(lines,['שם(?: הלקוח)?','לקוח','שם מקבל','מקבל','name','customer','الاسم','اسم الزبون','المستلم']);
  let address=valueAfterLabel(lines,['כתובת(?: למשלוח)?','מען','רחוב','address','delivery address','العنوان','عنوان']);
  if(!name){
    name=lines.find(l=>!/טלפון|כתובת|מען|מספר|הזמנה|משלוח|phone|address|order|رقم|عنوان|طلب/i.test(l)&&!extractPhone(l)&&l.length>=3&&l.length<=45)||'';
  }
  if(!address){
    address=lines.find(l=>/רחוב|כביש|שכונה|ירושלים|רמאללה|בית|street|road|st\.?|rd\.?|شارع|حي|القدس|رام الله/i.test(l)&&!extractPhone(l))||'';
  }
  if(phone){
    name=name.replace(phone,'').trim();address=address.replace(phone,'').trim();
  }
  return {name:name.slice(0,80),phone,address:address.slice(0,140),raw:normalizeOcrText(raw)};
}
async function runOcr(){
  const file=$('#photo').files[0];
  if(!file){toast('בחר תמונה קודם');return}
  if(!window.Tesseract){alert('רכיב הסריקה לא נטען. בדוק חיבור לאינטרנט ונסה שוב.');return}
  const btn=$('#scanPhoto'),status=$('#ocrStatus'),bar=$('#ocrProgress'),fill=$('#ocrProgress i');
  btn.disabled=true;bar.classList.remove('hidden');fill.style.width='3%';status.textContent='מכין את מנגנון הסריקה…';
  try{
    const result=await Tesseract.recognize(file,'heb+ara+eng',{logger:m=>{
      if(m.status==='recognizing text'){
        const pct=Math.max(3,Math.round((m.progress||0)*100));fill.style.width=pct+'%';status.textContent='סורק את התמונה… '+pct+'%';
      }else if(m.status){status.textContent='מעבד: '+m.status;}
    }});
    const f=extractFields(result.data.text||'');
    if(f.name)$('#name').value=f.name;
    if(f.phone)$('#phone').value=f.phone;
    if(f.address)$('#address').value=f.address;
    if(!$('#notes').value.trim()&&f.raw)$('#notes').value='טקסט שזוהה: '+f.raw.slice(0,500);
    fill.style.width='100%';
    const count=[f.name,f.phone,f.address].filter(Boolean).length;
    status.textContent=count?'הסריקה הסתיימה. בדוק ותקן את הפרטים לפני השמירה.':'הטקסט נקרא, אך לא נמצאו שדות ברורים. אפשר להעתיק מההערות.';
    toast('הסריקה הסתיימה');
  }catch(err){console.error(err);status.textContent='הסריקה נכשלה. נסה תמונה חדה יותר ובתאורה טובה.';alert('לא ניתן לקרוא את התמונה. ודא שיש אינטרנט ושהצילום ברור.');}
  finally{btn.disabled=false;setTimeout(()=>bar.classList.add('hidden'),1800)}
}
$('#scanPhoto').onclick=runOcr;
